package com.example.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entities.Presentacion;

public interface PresentacionDao extends JpaRepository<Presentacion, Long>{
    
}
