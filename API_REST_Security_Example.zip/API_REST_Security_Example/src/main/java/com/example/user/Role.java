package com.example.user;

public enum Role {
    ADMIN, USER
}
